import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import DevocionalScreen from './screens/DevocionalScreen';
import FinancasScreen from './screens/FinancasScreen';
import ProdutividadeScreen from './screens/ProdutividadeScreen';
import GestaoScreen from './screens/GestaoScreen';

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator screenOptions={{ headerShown: false }}>
        <Tab.Screen name="Devocional" component={DevocionalScreen} />
        <Tab.Screen name="Finanças" component={FinancasScreen} />
        <Tab.Screen name="Produtividade" component={ProdutividadeScreen} />
        <Tab.Screen name="Gestão" component={GestaoScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
